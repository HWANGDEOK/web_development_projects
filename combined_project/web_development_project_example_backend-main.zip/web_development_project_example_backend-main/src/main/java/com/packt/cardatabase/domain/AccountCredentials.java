package com.packt.cardatabase.domain;

public record AccountCredentials(String username, String password) {}